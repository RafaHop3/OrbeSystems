import asyncio
import httpx

async def run_e2e_test():
    async with httpx.AsyncClient(base_url="http://127.0.0.1:8000") as client:
        print("1. Testing Health Check...")
        r = await client.get("/health")
        print("   Health:", r.status_code, r.json())
        assert r.status_code == 200

        print("2. Registering Cooperativa Habitacional user...")
        email = "test_colab@orbe.com"
        r = await client.post("/api/v1/auth/register", json={
            "email": email,
            "full_name": "Cooperativa Habitacional Sol Nascente",
            "password": "SecurePass123!"
        })
        print("   Register status:", r.status_code, r.text)
        assert r.status_code == 201

        print("3. Logging in...")
        r = await client.post("/api/v1/auth/login", json={
            "email": email,
            "password": "SecurePass123!"
        })
        print("   Login status:", r.status_code, r.text)
        assert r.status_code == 200
        token_data = r.json()
        token = token_data["access_token"]
        assert token is not None

        headers = {"Authorization": f"Bearer {token}"}

        print("4. Fetching /users/me profile...")
        r = await client.get("/api/v1/users/me", headers=headers)
        print("   Users /me:", r.status_code, r.json())
        assert r.status_code == 200
        user_me = r.json()
        assert user_me["email"] == email

        print("5. Creating Billing Invoice...")
        r = await client.post("/api/v1/billing/invoices", json={
            "customer_name": "Cooperativa Habitacional Sol Nascente - Cota Apt 302",
            "customer_phone": "11999998888",
            "customer_email": "financeiro@solnascente.coop.br",
            "amount": 1500.0,
            "due_date": "2026-08-30",
            "description": "Cota de Construção - Bloco A Apt 302"
        }, headers=headers)
        print("   Create Invoice:", r.status_code, r.json())
        assert r.status_code == 201

        print("6. Fetching Billing Invoices & Summary...")
        r = await client.get("/api/v1/billing/invoices", headers=headers)
        print("   List Invoices:", r.status_code, "Total:", len(r.json()))
        assert r.status_code == 200

        r = await client.get("/api/v1/billing/summary", headers=headers)
        print("   Billing Summary:", r.status_code, r.json())
        assert r.status_code == 200

        print("\n🎉 ALL E2E API VERIFICATION STEPS PASSED 100%!")

if __name__ == "__main__":
    import traceback
    try:
        asyncio.run(run_e2e_test())
    except Exception as e:
        traceback.print_exc()
